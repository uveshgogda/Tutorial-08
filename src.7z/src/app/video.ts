export class Video{
    _id!: String;
    title!: String;
    desc!: String;
    posted_by!: String;
    url!: String;
    likes!: Number;
    cat!: [];
}